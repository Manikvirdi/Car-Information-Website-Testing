﻿
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;

namespace ClassLibrary6
{
	[TestFixture]
	public class Class1
	{
		private IWebDriver driver;
		private StringBuilder verificationErrors;
		private string baseURL;
		private bool acceptNextAlert = true;

		[SetUp]
		public void SetupTest()
		{
			driver = new FirefoxDriver();
			baseURL = "https://www.katalon.com/";
			verificationErrors = new StringBuilder();
		}

		[TearDown]
		public void TeardownTest()
		{
			try
			{
				driver.Quit();
			}
			catch (Exception)
			{
				// Ignore errors if unable to close the browser
			}
			Assert.AreEqual("", verificationErrors.ToString());
		}


		[Test]
		public void Website_EmptyFields_ResultMandatoryFields()
		{
			driver.Navigate().GoToUrl("http://localhost/html/form.html");
			driver.FindElement(By.XPath("//body")).Click();
			driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Vehicle Year:'])[1]/following::button[1]")).Click();
			driver.FindElement(By.Id("firstname")).Clear();
			driver.FindElement(By.Id("firstname")).SendKeys("Manik");
			driver.FindElement(By.Name("address1")).Click();
			driver.FindElement(By.Name("address1")).Clear();
			driver.FindElement(By.Name("address1")).SendKeys("56");
			driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Information about Cars'])[1]/following::form[1]")).Click();
			driver.FindElement(By.Name("city1")).Click();
			driver.FindElement(By.Name("city1")).Clear();
			driver.FindElement(By.Name("city1")).SendKeys("Toronto");
			driver.FindElement(By.Name("PhoneNumber1")).Click();
			driver.FindElement(By.Name("PhoneNumber1")).Clear();
			driver.FindElement(By.Name("PhoneNumber1")).SendKeys("123-123-1234");
			driver.FindElement(By.Name("email")).Click();
			driver.FindElement(By.Name("email")).Clear();
			driver.FindElement(By.Name("email")).SendKeys("manik@gmail.com");
			driver.FindElement(By.Name("makecar")).Click();
			driver.FindElement(By.Name("makecar")).Clear();
			driver.FindElement(By.Name("makecar")).SendKeys("Audi");
			driver.FindElement(By.Name("modelcar")).Click();
			driver.FindElement(By.Name("modelcar")).Clear();
			driver.FindElement(By.Name("modelcar")).SendKeys("A4");
			driver.FindElement(By.Name("yearcar")).Click();
			driver.FindElement(By.Name("yearcar")).Clear();
			driver.FindElement(By.Name("yearcar")).SendKeys("2018");
			driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Vehicle Year:'])[1]/following::button[1]")).Click();
			driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Car Model:A4'])[1]/following::h2[1]")).Click();
		}

		[Test]
		public void Website_FormJdLink_ResultJdWebsiteDisplayed()
		{
			driver.Navigate().GoToUrl("http://localhost/html/form.html");
			driver.FindElement(By.Id("firstname")).Click();
			driver.FindElement(By.Id("firstname")).Clear();
			driver.FindElement(By.Id("firstname")).SendKeys("Manu");
			driver.FindElement(By.Name("address1")).Click();
			driver.FindElement(By.Name("address1")).Clear();
			driver.FindElement(By.Name("address1")).SendKeys("87 Columbia Street");
			driver.FindElement(By.Name("city1")).Click();
			driver.FindElement(By.Name("city1")).Clear();
			driver.FindElement(By.Name("city1")).SendKeys("Waterloo");
			driver.FindElement(By.Name("PhoneNumber1")).Click();
			driver.FindElement(By.Name("PhoneNumber1")).Clear();
			driver.FindElement(By.Name("PhoneNumber1")).SendKeys("123-456-9876");
			driver.FindElement(By.Name("email")).Click();
			driver.FindElement(By.Name("email")).Clear();
			driver.FindElement(By.Name("email")).SendKeys("manu@gmail.com");
			driver.FindElement(By.Name("makecar")).Click();
			driver.FindElement(By.Name("makecar")).Clear();
			driver.FindElement(By.Name("makecar")).SendKeys("Lincoln");
			driver.FindElement(By.Name("modelcar")).Click();
			driver.FindElement(By.Name("modelcar")).Clear();
			driver.FindElement(By.Name("modelcar")).SendKeys("MKS");
			driver.FindElement(By.Name("yearcar")).Click();
			driver.FindElement(By.Name("yearcar")).Clear();
			driver.FindElement(By.Name("yearcar")).SendKeys("2014");
			driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Vehicle Year:'])[1]/following::button[1]")).Click();
			driver.FindElement(By.LinkText("https://jdpower.com/cars/2014/Lincoln/MKS")).Click();
		}


		[Test]
		public void Website_JdLinkInvalidData_ResultNotFound()
		{
			driver.Navigate().GoToUrl("http://localhost/html/form.html");
			driver.FindElement(By.Id("firstname")).Click();
			driver.FindElement(By.Id("firstname")).Clear();
			driver.FindElement(By.Id("firstname")).SendKeys("pammi");
			driver.FindElement(By.Name("address1")).Click();
			driver.FindElement(By.Name("address1")).Clear();
			driver.FindElement(By.Name("address1")).SendKeys("56 kings");
			driver.FindElement(By.Name("city1")).Click();
			driver.FindElement(By.Name("city1")).Clear();
			driver.FindElement(By.Name("city1")).SendKeys("Brampton");
			driver.FindElement(By.Name("PhoneNumber1")).Click();
			driver.FindElement(By.Name("PhoneNumber1")).Clear();
			driver.FindElement(By.Name("PhoneNumber1")).SendKeys("123-123-1234");
			driver.FindElement(By.Name("email")).Click();
			driver.FindElement(By.Name("email")).Clear();
			driver.FindElement(By.Name("email")).SendKeys("pammi@gmail.com");
			driver.FindElement(By.Name("makecar")).Click();
			driver.FindElement(By.Name("makecar")).Clear();
			driver.FindElement(By.Name("makecar")).SendKeys("lincon");
			driver.FindElement(By.Name("modelcar")).Click();
			driver.FindElement(By.Name("modelcar")).Clear();
			driver.FindElement(By.Name("modelcar")).SendKeys("MKS");
			driver.FindElement(By.Name("yearcar")).Click();
			driver.FindElement(By.Name("yearcar")).Clear();
			driver.FindElement(By.Name("yearcar")).SendKeys("2014");
			driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Vehicle Year:'])[1]/following::button[1]")).Click();
			driver.FindElement(By.LinkText("https://jdpower.com/cars/2014/lincon/MKS")).Click();
		}


		[Test]
		public void Website_EnterValues_ResultDataDisplayed()
		{
			driver.Navigate().GoToUrl("http://localhost/html/form.html");
			driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Vehicle Year:'])[1]/following::button[1]")).Click();
			driver.FindElement(By.Id("firstname")).Clear();
			driver.FindElement(By.Id("firstname")).SendKeys("Manu");
			driver.FindElement(By.Name("address1")).Click();
			driver.FindElement(By.Name("address1")).Clear();
			driver.FindElement(By.Name("address1")).SendKeys("76");
			driver.FindElement(By.Name("city1")).Click();
			driver.FindElement(By.Name("city1")).Clear();
			driver.FindElement(By.Name("city1")).SendKeys("Waterloo");
			driver.FindElement(By.Name("PhoneNumber1")).Click();
			driver.FindElement(By.Name("PhoneNumber1")).Clear();
			driver.FindElement(By.Name("PhoneNumber1")).SendKeys("654-987-9876");
			driver.FindElement(By.Name("email")).Click();
			driver.FindElement(By.Name("email")).Clear();
			driver.FindElement(By.Name("email")).SendKeys("manu@gmail.com");
			driver.FindElement(By.Name("makecar")).Click();
			driver.FindElement(By.Name("makecar")).Clear();
			driver.FindElement(By.Name("makecar")).SendKeys("Audi");
			driver.FindElement(By.Name("modelcar")).Click();
			driver.FindElement(By.Name("modelcar")).Clear();
			driver.FindElement(By.Name("modelcar")).SendKeys("A4");
			driver.FindElement(By.Name("yearcar")).Click();
			driver.FindElement(By.Name("yearcar")).Clear();
			driver.FindElement(By.Name("yearcar")).SendKeys("2018");
			driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Vehicle Year:'])[1]/following::button[1]")).Click();
			Assert.AreEqual("Information about Cars", driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Customer Name:Manu'])[1]/preceding::h2[1]")).Text);
		}



		[Test]
		public void Website_InvalidPhoneNumber_ResultError()
		{
			driver.Navigate().GoToUrl("http://localhost/html/form.html");
			driver.FindElement(By.Id("firstname")).Clear();
			driver.FindElement(By.Id("firstname")).SendKeys("Manik");
			driver.FindElement(By.Name("address1")).Click();
			driver.FindElement(By.Name("address1")).Clear();
			driver.FindElement(By.Name("address1")).SendKeys("65");
			driver.FindElement(By.Name("city1")).Click();
			driver.FindElement(By.Name("address1")).Click();
			driver.FindElement(By.Name("address1")).Clear();
			driver.FindElement(By.Name("address1")).SendKeys("65 Kings");
			driver.FindElement(By.Name("city1")).Click();
			driver.FindElement(By.Name("city1")).Clear();
			driver.FindElement(By.Name("city1")).SendKeys("Waterloo");
			driver.FindElement(By.Name("PhoneNumber1")).Click();
			driver.FindElement(By.Name("PhoneNumber1")).Clear();
			driver.FindElement(By.Name("PhoneNumber1")).SendKeys("1234567890");
			driver.FindElement(By.Name("email")).Click();
			driver.FindElement(By.Name("PhoneNumber1")).Click();
			driver.FindElement(By.Name("PhoneNumber1")).Clear();
			driver.FindElement(By.Name("PhoneNumber1")).SendKeys("987-876-0987");
			driver.FindElement(By.Name("email")).Click();
			driver.FindElement(By.Name("email")).Clear();
			driver.FindElement(By.Name("email")).SendKeys("manik@gmail.com");
			driver.FindElement(By.Name("makecar")).Click();
			driver.FindElement(By.Name("makecar")).Clear();
			driver.FindElement(By.Name("makecar")).SendKeys("Audi");
			driver.FindElement(By.Name("modelcar")).Click();
			driver.FindElement(By.Name("modelcar")).Clear();
			driver.FindElement(By.Name("modelcar")).SendKeys("A4");
			driver.FindElement(By.Name("yearcar")).Click();
			driver.FindElement(By.Name("yearcar")).Click();
			driver.FindElement(By.Name("yearcar")).Clear();
			driver.FindElement(By.Name("yearcar")).SendKeys("2018");
			Assert.AreEqual("Vehicle Year:", driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Vehicle Model:'])[1]/following::label[1]")).Text);
		}

		private bool IsElementPresent(By by)
		{
			try
			{
				driver.FindElement(by);
				return true;
			}
			catch (NoSuchElementException)
			{
				return false;
			}
		}

		private bool IsAlertPresent()
		{
			try
			{
				driver.SwitchTo().Alert();
				return true;
			}
			catch (NoAlertPresentException)
			{
				return false;
			}
		}

		private string CloseAlertAndGetItsText()
		{
			try
			{
				IAlert alert = driver.SwitchTo().Alert();
				string alertText = alert.Text;
				if (acceptNextAlert)
				{
					alert.Accept();
				}
				else
				{
					alert.Dismiss();
				}
				return alertText;
			}
			finally
			{
				acceptNextAlert = true;
			}
		}
	}
}
