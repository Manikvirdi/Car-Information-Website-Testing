<?php
$firstname = $_REQUEST['firstname'];
$address = $_REQUEST['address1'];
$city = $_REQUEST['city1'];
$phonenumber = $_REQUEST['PhoneNumber1'];
$email = $_REQUEST['email'];
$makecar = $_REQUEST['makecar'];
$modelcar = $_REQUEST['modelcar'];
$yearcar = $_REQUEST['yearcar'];
$link = "https://jdpower.com/cars/$yearcar/$makecar/$modelcar";

$servername = "localhost";
$username = "root";
$password = "";
$database = "test1";

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("The Connection failed: " . mysqli_connect_error());
	
} 
else
{
echo "Connected successfully!";
}

$sql = "INSERT INTO `information` (`Customer_Name`, `Address`, `City`, `Phone_Number`, `Email`, `Vehicle_Make`, `Vehicle_Model`, `Vehicle_Year`) 
VALUES ('$firstname', '$address', '$city', '$phonenumber', '$email', '$makecar', '$modelcar', '$yearcar')";


$conn->query($sql);
?>

<!DOCTYPE html
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
</style>
</head>
<body>

<h2>Information about Cars</h2>
<p>Information entered by user:</p>

<h2>Customer Name:<?php echo $firstname; ?></h2>
<h2>Address:<?php echo $address; ?></h2>
<h2>City:<?php echo $city; ?></h2>
<h2>Phone Number:<?php echo $phonenumber; ?></h2>
<h2>Email:<?php echo $email; ?></h2>
<h2>Car Make:<?php echo $makecar; ?></h2>
<h2>Car Model:<?php echo $modelcar; ?></h2>
<h2>Car Year:<?php echo $yearcar; ?></h2>
<h2>Link:<a href ="<?php echo $link ?>"><?php echo $link ?></a></h2>

<div class="tab">
  <button class="tablinks" onclick="openhome(event, 'home')"><a href="./main.php" target="_blank">Home</a></button>
</div>

   
</body>
</html> 
