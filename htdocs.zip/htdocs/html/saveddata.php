
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>
</head>
<body>

<h2>Information about Cars</h2>
<p>List of all saved data</p>

<div class="tab">
  <button class="tablinks" onclick="openhome(event, 'home')"><a href="./main.php" target="_blank">Home</a></button>
</div>

</body>
</html> 
<?php


$servername = "localhost";
$username = "root";
$password = "";
$database = "test1";

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("The Connection failed: " . mysqli_connect_error());
	
} 
else
{
//echo "Connected successfully!";
}


$sql = "SELECT Customer_Name, Address, City, Phone_Number, Email, Vehicle_Make, Vehicle_Model, Vehicle_Year FROM information ORDER BY Customer_Id DESC";
$result = $conn->query($sql);

   
    while($row = $result->fetch_assoc()) 
	{
        echo "<br>"."Customer Name: " . $row["Customer_Name"] ."<br>". " Address:" . $row["Address"]."<br>". "City:" . $row["City"]. "<br>"."PhoneNumber:" .
		$row["Phone_Number"]."<br>".
		"Email:" . $row["Email"]."<br>". "Make:" . $row["Vehicle_Make"]."<br>". "Model:" . $row["Vehicle_Model"]."<br>". "Year:" . $row["Vehicle_Year"]."<br>"."---------";
    }
 



$conn->query($sql);
?>