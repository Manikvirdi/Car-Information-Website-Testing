<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.tab1
{
margin-left:0px;
}
.tab1
{
margin-left:25px;
}
</style>
</head>
<body>


<h2>Information about Cars</h2>
<p>Click on the buttons inside the tabbed menu:</p><br><br>

<div>
  <button class="tablinks" class="tab1" onclick="opennew(event, 'new')"><a href="./form.html" target="_blank">New</a></button>
  <button class="tablinks" class="tab2" onclick="opensearch(event, 'search')"><a href="./saveddata.php" target="_blank">Search</a></button>
</div>


   
</body>
</html> 